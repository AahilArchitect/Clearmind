package isp;
import hsa_ufa.*;
import java.awt.*;

import javax.swing.*;

public class RPGGame{
	// game constructor will upload images to room
	private Hero hero;
	private Room[] rooms;
	private int currentRoom;
	public String[][] tempQAndA = new String[2][10];
	Console con = new Console(900,700);
	public void setQANDA() {
		for(int i = 0; i<2;i++) { 
			for(int ii = 0; ii<10;ii++) {
				if(i == 0) {
					tempQAndA[i][ii] = "Q";}
				else {
					tempQAndA[i][ii] = "A";
				}
			}
		}
	}
	public void startGame() {
		con.addMouseListener(con);
		rooms = new Room [4];
		//jack.setSize(900,700);
		//jack.setVisible(true);
		String[] tempp = {"North","North","North","North","West", "West","East","South"};
		//Each array of wall co has one extra wall at teh front for the invisible wall 
		int [] temp = {100,300,0,330,0,100,0,330,300,400,0,330,400,900,0,50,0,20,0,700,350,447,0,330,790,900,0,700,0,900,575,690};
		int [] startingHere = {600,700,200,400};
		int [] endingHere = {200,300,0,200};
		//because ending is like this make sure the walls near stairs are thick and be sure the ending box extends into them
		rooms[0]= new Room("images\\BG1.png", 7, temp, con, startingHere, tempp, endingHere);
//rpt for 1,2,3, use rand for the next part
		//backgroundAndGraphics test = new backgroundAndGraphics(rooms[0].background);
		hero = new Hero(con, rooms[0]);
		hero.move();
		
	}
	public void nextRoom(){
		hero.currentRoom = rooms[(int)((Math.random()+1)*4)];
	}
	public boolean readyForBoss() {
		// look through question list, maybe 10 per game(with associated list of 'has this been done correctly?'
			// if everything is done, a separate 5 question list is for the boss fight
		return true;
	}
	public static boolean checkAnswer(/* questions and answers list, whatever form thats in */ ){
		return true;
	}
	public void isGameOver(){
	}
	}


