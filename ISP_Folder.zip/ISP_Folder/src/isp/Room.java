package isp;
import hsa_ufa.*;
import java.awt.*;
public class Room{
private int id; //huh
private String type; //huh
public Enemy[] enemy;
public boolean isBossRoom;
public int howManyEnemy;
private Wall[] walls;
private int wallNumber;
public Image background;
public Image fightBG;
private Console c;
public int[] startPlacement = new int[4];
public int[] endPlacement = new int[4];
public int[] falseWall = new int[4];


public Room(String im, int wallNum, int []wallLocations, Console con, int[] idecMan, String[] directions, int[] end) {
	//wallLocations can feed into the initialization of each wall object for this room
	this.c = con;
	background = Toolkit.getDefaultToolkit().getImage(im);
	fightBG= Toolkit.getDefaultToolkit().getImage("images\\fightBG.png");
	this.walls = new Wall [wallNum+1];
	this.wallNumber=wallNum;
	endPlacement = end;
	startPlacement = idecMan;
	howManyEnemy = (int)((Math.random()+1)*2);
	enemy = new Enemy [howManyEnemy];
	int tempx, tempy,counter=0;
	int [] temporary = new int[4];
	Boolean ok = true;
	for(int i = 0; i<=wallNum;i++) {
		for(int ii = 0; ii<4; ii++) {
			temporary[ii] = wallLocations[counter+ii];
		}
		counter += 4;
		if (i== 0){
			walls[i]= new Wall(temporary, directions[i],false);
		}
		else{
			walls[i]= new Wall(temporary, directions[i],true);
		}
		c.fillRect(temporary[0], temporary[2],(temporary[1]-temporary[0]), (temporary[3]-temporary[2]));
	}
	for(int i = 0; i<howManyEnemy;i++) {
		//edit this later to ensure enemies can't spawn on walls either
		do {
			tempx = (int)(Math.random()*780);
			tempy = (int)(Math.random()*650);
			//adaptive with heros start ,, which depends on the room ahh
			if (idecMan[0]<tempx && idecMan[1]>tempx &&idecMan[2]<tempy&&idecMan[0]>tempy) {
				ok = false;
			}
			else if(hitWall(tempx, tempy)==true) {
				ok = false;
			}
			else {
				ok = true;
			}
		} while(ok == false);
		enemy[i] = new Enemy(c, tempx,tempy,false);
		//actual drawing of enemy will be moved to enemy object later and run either through room by hero or just by hero
	}	
	
}
public boolean hitWall(int x,int y){
	for(int i = 0; i<=wallNumber;i++) {
			if(walls[i].hitQuestionMark(x, y)==true) {
				return true;
			}
	}
	
	return false;
}
public boolean hitWall(int x,int y, String typ){
	for(int i = 0; i<=wallNumber;i++) {
		if(walls[i].type.compareToIgnoreCase(typ)==0) {
			if(walls[i].hitQuestionMark(x, y)==true) {
				return true;
			}
		}
	}
	return false;
}
public Enemy getEnemy(int which){
	return enemy[which];

}

/*public boolean isBossRoom(){
	
	return false;
}*/
}

