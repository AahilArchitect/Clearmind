package isp;
import java.awt.*;
import javax.swing.*;

public class backgroundAndGraphics extends JFrame{
	public backgroundAndGraphics(Image im) {
		this.setVisible(true);
	JLabel son = new JLabel(new ImageIcon(im));
	this.setContentPane(son);
	this.pack();
	this.setSize(900,700);
}
}
