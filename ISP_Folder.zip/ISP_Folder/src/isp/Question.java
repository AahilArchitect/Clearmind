package isp;
import hsa_ufa.*;
import java.awt.*;
public class Question{
private String prompt;
private String answer;
private String[][] options = new String[2][10];
private String[][] bossOptions = new String[2][5];
private boolean[][] optionsCorrect = new boolean [2][10];
private boolean[][] bossOptionsCorrect = new boolean[2][5];
private String source;
private String type;

public boolean check(){
	//checks answers with the arrays
	return true;
}
public String getType(){
	return type;
}
public void displayquestion() {
	
}
}




