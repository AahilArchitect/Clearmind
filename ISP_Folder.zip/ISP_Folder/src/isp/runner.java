package isp;

public class runner {
	public static void main(String[]args) {
		RPGGame r = new RPGGame();
		r.setQANDA();
		r.startGame();
	}
}



