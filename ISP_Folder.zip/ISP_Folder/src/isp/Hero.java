package isp;
import hsa_ufa.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;

public class Hero {
private int HP=200;
private int attack;
private int level;
private int defence;
public int[] xOfHero = new int[2];
public int[] yOfHero = new int[2];
public Room currentRoom;
public boolean inFight = false;
private int idOfEnemy;
Image HeroSprite[] = new Image[2];
Image HeroStanding;
private boolean walkCycle= false;
Console c;
public Hero(Console con, Room firstRoom) { 
	   c = con;
	   try {
		   currentRoom=firstRoom;
		   xOfHero[0] = currentRoom.startPlacement[0]+10;
		   xOfHero[1] = xOfHero[0]+50;
		   yOfHero[0] = currentRoom.startPlacement[2]+10;
		   yOfHero[1] = yOfHero[0]+100;
		   HeroStanding = Toolkit.getDefaultToolkit().getImage("images\\Real_Base_Wizard.png");
		   HeroSprite[0] = Toolkit.getDefaultToolkit().getImage("images\\Wizard_Walking_1.png");
		   HeroSprite[1] = Toolkit.getDefaultToolkit().getImage("images\\Wizard_walking_2.png");
		   c.drawImage(currentRoom.background, 0, 0, 900, 700);
	       c.drawImage(HeroStanding, xOfHero[0], yOfHero[0], 60, 100);
	   }catch(RuntimeException e) {
       System.out.println("error");
       } 
}

public void move(){
	try {
		//the boolean being argued may change
		while(inFight==false) {
			//if,, use same code to test overlap in room for 
			//making enemies to test for overlapping on enemies,, somewhat similar logic for walls but thats self contained
			//endpoint if below
			/*if() {
				
			} */
			//wall if below
			
			if(c.isKeyDown('A')) {
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "West")==false) {
					xOfHero[0]-=3;
					xOfHero[1]-=3;
					c.drawImage(currentRoom.background, 0, 0, 900, 700);
					c.drawImage(HeroSprite[walkCycle()], xOfHero[0], yOfHero[0], 60, 100);
				}
					//current room dot hit wall so its adaptive
			}
			else if(c.isKeyDown('D')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "East")==false) {
				xOfHero[0]+=3;
				xOfHero[1]+=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0]+60, yOfHero[0], -60, 100);
				}
			}
			else if(c.isKeyDown('W')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "North")==false) {
				yOfHero[0]-=3;
				yOfHero[1]-=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0], yOfHero[0], 60, 100);
				}
			}
			else if(c.isKeyDown('S')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "South")==false) {
				yOfHero[0]+=3;
				yOfHero[1]+=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0]+60, yOfHero[0], -60, 100);
				}
			}
			else {
				
			}
			//this will be removed most likely, but if not add a for to go through all the enemies based on how many are in the room
			for(int ii = 0; ii<currentRoom.howManyEnemy;ii++) {
				if(currentRoom.getEnemy(ii).Exist(xOfHero,yOfHero)==true) {
					idOfEnemy = ii;
					inFight = true;
				}
			}
			//currentRoom.blockade();
			Thread.sleep(5);
		}
		//catch if u hit an enemy
	}catch(InterruptedException ee) {
	
}
	if(inFight == true) {
		Fight(idOfEnemy);
	}
}
private int walkCycle() {
	if(walkCycle == true) {
		walkCycle = false;
		return 1;
	}
	else {
		walkCycle = true;
		return 0;
	}
}
public void Fight(int whichEnemy) {
	//change this to check your xs and enemy hitbox
	Enemy fightingNow = currentRoom.getEnemy(whichEnemy);
	c.clear();
	c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
	fightingNow.Exist();
	c.setColor(Color.black);
	c.drawImage(HeroStanding, 500, 380, 90, 150);
	c.fillRect(490, 550, 400, 150);
	c.setColor(Color.red);
	c.fillRect(495, 555, 390, 65);
	c.setColor(Color.blue);
	c.fillRect(495, 630, 390, 65);
	while (inFight==true&&isAlive()==true) {
		
	}
	//call move after its done
	//call take damage
}
public void takeDamage(Enemy enem){
	HP -= enem.attackHero();
	isAlive();
}
/*	public void levelUp(){
	} */
private boolean isAlive(){
	if(HP<=0) {
		//temp value
		boolean rply=false;
		if(rply==false) {
			c.close();
		}
		else {
			
		}
		//ask for replay
	}
	return true;
}
private void moveRoom() {
	/*if (xLocation[0]<x && xLocation[2]>x &&yLocation[0]<y&&yLocation[2]>y) {
		return true;
	}*/
}


}



