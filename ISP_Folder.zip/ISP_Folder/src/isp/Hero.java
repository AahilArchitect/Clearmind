package isp;
import hsa_ufa.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;

public class Hero {
private int HP=200;
private int attack;
private int level;
private int defence;
public int[] xOfHero = new int[2];
public int[] yOfHero = new int[2];
public Room currentRoom;
public boolean inFight = false;
private JPanel p;
private int idOfEnemy;
Image HeroSprite[] = new Image[2];
Image HeroStanding;
private int walkCycle=0;
Console c;
public Hero(Console con, Room firstRoom) { 
	   c = con;
	   try {
		   currentRoom=firstRoom;
		   xOfHero[0] = currentRoom.startPlacement[0];
		   xOfHero[1] = xOfHero[0]+100;
		   yOfHero[0] = currentRoom.startPlacement[2];
		   yOfHero[1] = yOfHero[0]+100;
		   HeroStanding = Toolkit.getDefaultToolkit().getImage("images\\Real_Base_Wizard.png");
		   HeroSprite[0] = Toolkit.getDefaultToolkit().getImage("images\\Wizard.png");
	       c.drawImage(HeroStanding, xOfHero[0], yOfHero[0], 100, 100);
	   }catch(RuntimeException e) {
       System.out.println("error");
       } 
}

public void move(){
	try {
		while(inFight==false) {
			//if,, use same code to test overlap in room for 
			//making enemies to test for overlapping on enemies,, somewhat similar logic for walls but thats self contained
			//endpoint if below
			/*if() {
				
			} */
			//wall if below
			
			if(c.isKeyDown('A')) {
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "West")==false) {
					xOfHero[0]-=5;
					xOfHero[1]-=5;
					c.drawImage(currentRoom.background, 0, 0, 900, 700);
					c.drawImage(HeroSprite[walkCycle], xOfHero[0], yOfHero[0], 100, 100);
				}
					//current room dot hit wall so its adaptive
			}
			else if(c.isKeyDown('D')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "East")==false) {
				xOfHero[0]+=5;
				xOfHero[1]+=5;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle], xOfHero[0], yOfHero[0], 100, 100);
				}
			}
			else if(c.isKeyDown('W')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "North")==false) {
				yOfHero[0]-=5;
				yOfHero[1]-=5;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle], xOfHero[0], yOfHero[0], 100, 100);
				}
			}
			else if(c.isKeyDown('S')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "South")==false) {
				yOfHero[0]+=5;
				yOfHero[1]+=5;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle], xOfHero[0], yOfHero[0], 100, 100);
				}
			}
			else {
				
			}
			//this will be removed most likely, but if not add a for to go through all the enemies based on how many are in the room
			for(int ii = 0; ii<currentRoom.howManyEnemy;ii++) {
				if(currentRoom.getEnemy(ii).Exist(xOfHero,yOfHero)==true) {
					idOfEnemy = ii;
					inFight = true;
				}
			}
			Thread.sleep(5);
		}
		//catch if u hit an enemy
	}catch(InterruptedException ee) {
	
}
	if(inFight == true) {
		Fight(idOfEnemy);
	}
}
public void Fight(int whichEnemy) {
	//change this to check your xs and enemy hitbox
	Enemy fightingNow = currentRoom.getEnemy(whichEnemy);
	c.clear();
	c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
	fightingNow.Exist();
	c.drawImage(HeroStanding, 500, 380, 150, 150);
	//call move after its done
	//call take damage
}
public void takeDamage(Enemy son){
	HP -= son.attackHero();
	isAlive();
}
/*	public void levelUp(){
	} */
private void isAlive(){
	if(HP<=0) {
		//temp value
		boolean rply=false;
		if(rply==false) {
			c.close();
		}
		else {
			
		}
		//ask for replay
	}

}
private void moveRoom() {
	/*if (xLocation[0]<x && xLocation[2]>x &&yLocation[0]<y&&yLocation[2]>y) {
		return true;
	}*/
}


}



