package isp;
import hsa_ufa.*;
import java.awt.*;
public class HealthBar {
	public int healthBarWidth= 400;
	public int healthBarBaseWidth= 410;
	private Color heartColor=Color.decode("#F2B3B9");
	private Color borderColor=Color.decode("#343231");
	private Color healthColor=Color.decode("#A8DCAB");
	private Color healthLossColor=Color.decode("#7E7E7E");
	private Console c;
	public HealthBar(int hpOfHero, Console co) {
		this.healthBarWidth = hpOfHero*2;
		this.c = co;
	}
	public void drawHealthBar() {
		c.setColor(borderColor);
		c.fillRect(0,650,healthBarBaseWidth,50);
		c.setColor(healthColor);
		c.fillRect(5,655,healthBarWidth,40);
	}
	public void loseHealth(int hp) {
		c.setColor(borderColor);
		c.fillRect(0,650,healthBarBaseWidth,50);
		c.setColor(healthLossColor);
		c.fillRect(5,655,healthBarWidth,40);
		healthBarWidth = hp*2;
		c.setColor(healthColor);
		c.fillRect(5,655,healthBarWidth,40);
	}

}
