package isp;
import hsa_ufa.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;

public class Hero {
private int HP=200;
private int attack=10;
private int level=1;
private int defence=3;
public int[] xOfHero = new int[2];
public int[] yOfHero = new int[2];
public Room currentRoom;
public boolean inFight = false, readyForNextRoom=false;
public boolean life=true;
private int idOfEnemy;
Image HeroSprite[] = new Image[2];
Image HeroStanding;
Image HeroAttack;
public int roomsCleared = 0;
private boolean walkCycle= false;
RPGGame game;
HealthBar barOfHealth;
//private int streak;
//^ tracks how many questions you got right in a row and gives you HP boosts
Console c;
public Hero(Console con, Room firstRoom, RPGGame g) { 
	   c = con;
	   game = g;
	   try {
		   currentRoom=firstRoom;
		   xOfHero[0] = currentRoom.startPlacement[0]+80;
		   xOfHero[1] = xOfHero[0]+120;
		   yOfHero[0] = currentRoom.startPlacement[2]+50;
		   yOfHero[1] = yOfHero[0]+140;
		   barOfHealth = new HealthBar(HP,c);
		   HeroStanding = Toolkit.getDefaultToolkit().getImage("images\\Real_Base_Wizard.png");
		   HeroAttack = Toolkit.getDefaultToolkit().getImage("images\\Wizard.png");
		   HeroSprite[0] = Toolkit.getDefaultToolkit().getImage("images\\Wizard_Walking_1.png");
		   HeroSprite[1] = Toolkit.getDefaultToolkit().getImage("images\\Wizard_walking_2.png");
		   c.drawImage(currentRoom.background, 0, 0, 900, 700);
	       c.drawImage(HeroStanding, xOfHero[0], yOfHero[0], 60, 100);
	   }catch(RuntimeException e) {
       System.out.println("error");
       } 
}

public void move(){
	try {
		//the boolean being argued may change
		while(inFight==false) {
			//if,, use same code to test overlap in room for 
			//making enemies to test for overlapping on enemies,, somewhat similar logic for walls but thats self contained
			//wall if below
			if(c.isKeyDown('A')) {
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "West")==false) {
					xOfHero[0]-=3;
					xOfHero[1]-=3;
					c.drawImage(currentRoom.background, 0, 0, 900, 700);
					c.drawImage(HeroSprite[walkCycle()], xOfHero[0], yOfHero[0], 60, 100);
				}
					//current room dot hit wall so its adaptive
			}
			else if(c.isKeyDown('D')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "East")==false) {
				xOfHero[0]+=3;
				xOfHero[1]+=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0]+60, yOfHero[0], -60, 100);
				}
			}
			else if(c.isKeyDown('W')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "North")==false) {
				yOfHero[0]-=3;
				yOfHero[1]-=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0], yOfHero[0], 60, 100);
				}
			}
			else if(c.isKeyDown('S')){
				if(currentRoom.hitWall(xOfHero[0], yOfHero[0], "South")==false) {
				yOfHero[0]+=3;
				yOfHero[1]+=3;
				c.drawImage(currentRoom.background, 0, 0, 900, 700);
				c.drawImage(HeroSprite[walkCycle()], xOfHero[0]+60, yOfHero[0], -60, 100);
				}
			}
			else {
				
			}
			//this will be removed most likely, but if not add a for to go through all the enemies based on how many are in the room
			for(int ii = 0; ii<currentRoom.howManyEnemy;ii++) {
				if(currentRoom.getEnemy(ii).Exist(xOfHero,yOfHero)==true) {
					idOfEnemy = ii;
					inFight = true;
				}
			}
			if(currentRoom.overEnd(xOfHero, yOfHero)==true) {
				roomsCleared+=1;
				readyForNextRoom=true;
				inFight=true;
			}
			Thread.sleep(5);
		}
	}catch(InterruptedException ee) {
	
}
	if(readyForNextRoom == true) {
		if(game.isGameOver()==true) {
			try {
			Thread.sleep(500);
			}catch(InterruptedException ee) {}
			c.close();
		}
		else {
			inFight=false;
			readyForNextRoom=false;
			//change rooms, change x to the new start point and stuff, call move room
		}
	}
	else if(inFight == true) {
		Fight(idOfEnemy);
	}
}

private int walkCycle() {
	if(walkCycle == true) {
		walkCycle = false;
		return 1;
	}
	else {
		walkCycle = true;
		return 0;
	}
}
public void Fight(int whichEnemy) {
	//change this to check your xs and enemy hitbox
	Enemy fightingNow = currentRoom.getEnemy(whichEnemy);
	boolean somethingHappened=false, defending=false;
	c.clear();
	c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
	fightingNow.Exist();
	c.drawImage(HeroStanding, 500, 380, 90, 150);
	OptionsGraphic();
	barOfHealth.drawHealthBar();
	while (inFight==true) {
		if(c.getMouseButton(0)==true) {
			if(495<c.getMouseX()&&885>c.getMouseX()&&550<c.getMouseY()&&620>c.getMouseY()) {
				c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
				fightingNow.Exist();
				c.drawImage(HeroAttack, 500, 380, 90, 150);
				barOfHealth.drawHealthBar();
				inFight=fightingNow.takeDamage(attack);
				somethingHappened = true;
				try {
					Thread.sleep(300);
				}catch(InterruptedException e) {}
				c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
				fightingNow.Exist();
				c.drawImage(HeroStanding, 500, 380, 90, 150);
				barOfHealth.drawHealthBar();
			}
			else if(495<c.getMouseX()&&885>c.getMouseX()&&630<c.getMouseY()&&695>c.getMouseY()){
				defending=true;
				defence +=3;
				somethingHappened=true;
			}
			if(somethingHappened ==true&& inFight==true) {
				somethingHappened = false;
				c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
				c.drawImage(HeroStanding, 500, 380, 90, 150);
				try {
					if(fightingNow.behave(HP)==true) {
						this.takeDamage(fightingNow);
						barOfHealth.loseHealth(HP);
					}
					Thread.sleep(300);
				}catch(InterruptedException e) {}
				c.drawImage(currentRoom.fightBG, 0, 0, 900, 700);
				fightingNow.Exist();
				c.drawImage(HeroStanding, 500, 380, 90, 150);
				if(defending==true) {
					defending = false;
					defence-=3;
				}
				barOfHealth.drawHealthBar();
				OptionsGraphic();
			
			}
		}
	}
	if(inFight==false) {
		c.drawImage(currentRoom.background, 0, 0, 900, 700);
		c.drawImage(HeroStanding, xOfHero[0], yOfHero[0], 60, 100);
		currentRoom.checkEnemiesDead();
		this.move();
	}
}
public void OptionsGraphic() {
	c.setColor(Color.black);
	c.fillRect(490, 550, 400, 150);
	c.setColor(Color.red);
	c.fillRect(495, 555, 390, 65);
	c.setColor(Color.blue);
	c.fillRect(495, 630, 390, 65);
	c.setColor(Color.BLACK);
//	c.drawString("Attack", 590, 570);
}
public void takeDamage(Enemy enem){
	HP -= enem.attackHero()/(defence/2);
	isAlive();
}
/*	public void levelUp(){
	} */
private void isAlive(){
	if(HP<=0) {
		c.setColor(Color.blue);
		c.fillRect(0, 0, 900, 700);
		OptionsGraphic();
		boolean rply=false;
		while(rply==false) {
			if(c.getMouseButton(0)==true) {
				if(495<c.getMouseX()&&885>c.getMouseX()&&550<c.getMouseY()&&620>c.getMouseY()) {
					rply=true;
					game.restart();	
				}
				else if(495<c.getMouseX()&&885>c.getMouseX()&&630<c.getMouseY()&&695>c.getMouseY()){
					try {
						c.setColor(Color.black);
						c.fillRect(0, 0, 900, 700);
						Thread.sleep(500);
					}catch(InterruptedException ee) {}
					c.close();
				}
			}
			}
	}
	//temp value
			/*
			*/
			//ask for replay
}
private void moveRoom() {
	/*if (xLocation[0]<x && xLocation[2]>x &&yLocation[0]<y&&yLocation[2]>y) {
		return true;
	}*/
}


}






