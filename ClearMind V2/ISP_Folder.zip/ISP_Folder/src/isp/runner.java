package isp;

public class runner {

public static void main(String[]args) {
	tempRun r = new tempRun();
}}




