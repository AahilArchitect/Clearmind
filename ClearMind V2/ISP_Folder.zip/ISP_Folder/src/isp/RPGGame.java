package isp;
import hsa_ufa.*;
import java.awt.*;

import javax.swing.*;

public class RPGGame{
	// game constructor will upload images to room
	private Hero hero;
	private Room[] rooms;
	private int currentRoom;
	public int RoomsToGetThrough=1;
	public String[][] tempQAndA = new String[2][10];
	Console con = new Console(900,700);
	tempRun runs;
	public void setQANDA() {
		for(int i = 0; i<2;i++) { 
			for(int ii = 0; ii<10;ii++) {
				if(i == 0) {
					tempQAndA[i][ii] = "Q";}
				else {
					tempQAndA[i][ii] = "A";
				}
			}
		}
	}
	public void startGame(tempRun r) {
		runs = r;
		con.enableMouse();
		rooms = new Room [4];
		// add 2 walls for inside the thing
		String[] tempp = {"North","North","North","North","West", "West","East","South","West","East","North"};
		//Each array of wall co has one extra wall at teh front for the invisible wall 
		int [] temp = {100,300,0,330,0,100,0,330,300,400,0,330,400,900,0,50,0,20,0,700,350,447,0,330,790,900,0,700,0,900,575,700,0,70,0,330,250,370,0,330,0,447,0,150};
		int [] startingHere = {500,700,200,400};
		int [] endingHere = {70,250,150,200};
		//because ending is like this make sure the walls near stairs are thick and be sure the ending box extends into them
		rooms[0]= new Room("images\\BG1.png", 10, temp, con, startingHere, tempp, endingHere);
//rpt for 1,2,3, use rand for the next part
		String[] tempp2 = {"South","North","North","East","East","East","East","West","West","West","West","South","South","South","South"};
		int [] temp2 = {327,550,450,700/*1-HERE*/, 0,900,0,50/*2*/,327,545,350,400/*3*/,790,900,0,700/*4*/,327,400,150,350/*5*/,300,480,460,700/*6-HERE*/,560,575,460,700/*7-HERE*/,0,20,0,700/*8*/,500,550,150,350/*9*/,327,480,460,700/*10-HERE*/,530,580,460,700/*11-HERE*/,0,900,575,700/*12*/,327,545,150,300/*13*/,327,450,450,700/*14*/,530,550,450,700};
		int [] startingHere2 = {100,200,500,700};
		int [] endingHere2 = {450,500,620,750};
		rooms[1]=new Room("images\\BG_2.png", 14, temp2, con, startingHere2, tempp2, endingHere2);
		hero = new Hero(con, rooms[(int)((Math.random())*2)], this);
		hero.move();
		con.disableMouse();
	}
	public void nextRoom(){
		hero.currentRoom = rooms[(int)((Math.random()+1)*4)];
	}
	public boolean readyForBoss() {
		// look through question list, maybe 10 per game(with associated list of 'has this been done correctly?'
			// if everything is done, a separate 5 question list is for the boss fight
		//or something
		return true;
	}
	public static boolean checkAnswer(/* questions and answers list, whatever form thats in */ ){
		return true;
	}
	public void restart() {
		runs.endGame(this);
	}
	public boolean isGameOver(){
		if(RoomsToGetThrough <= hero.roomsCleared) {
			con.drawImage(Toolkit.getDefaultToolkit().getImage("images\\250px-Hadestown_musical_poster.png"),0,0,900,700);
			return true;
		}
		return false;
	}
	public void GameOver() {
		runs.endGame(this);
	}
	}




