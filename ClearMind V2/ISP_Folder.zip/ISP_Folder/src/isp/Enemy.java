package isp;
import hsa_ufa.*;
import java.awt.*;
public class Enemy{
public int hp= 30;
private int defense=0;
private int damage = 10;
public boolean life=true;
public boolean charging = false;
//what
//give boss special attacks and enemies a 25% chance to charge for double damage
//private boolean attacking= false;
//x and y location [2] will be the hit box end
public int[] xLocation = new int[3];
public int[] yLocation = new int[3];
public Image spriteOfEnemy = Toolkit.getDefaultToolkit().getImage("images\\SlimeDotPNG.png");
public Image spriteOfEnemyattack = Toolkit.getDefaultToolkit().getImage("images\\Slime_attacking.png");
public Image deathSprite = Toolkit.getDefaultToolkit().getImage("images\\Death_of_a_slime.png");
private Console c;
//make use of javas garbage collection to kill enemies? don't name them and use  hero or room reference?
public Enemy(Console con, int x, int y) {
	//make boss a child of enemy
	this.c = con;
	xLocation[0]= x;
	xLocation[1]= x+50;
	yLocation[0]= y;
	yLocation[1]= y+50;
	xLocation[2]= x+30;
	yLocation[2]= y+30;
}
public void Exist() {
	c.drawImage(spriteOfEnemy,170 ,500,200,150);
	if(charging == true) {
		c.setColor(Color.yellow);
		c.fillRect(170+10,500,10,25);
		c.fillRect(370,600,10,25);
		c.fillRect(170,500+40,10,25);
	}
}
public void ExistAngerly() {
	c.drawImage(spriteOfEnemyattack,170 ,500,200,150);
	
}
public void chargeEnergy() {
	charging = true;
}
public void chargeAttack() {
	charging = false;
	damage*=2;
	c.drawImage(spriteOfEnemyattack,170 ,500,200,150);
	if(charging == true) {
		c.setColor(Color.yellow);
		c.fillRect(170+10,500,10,25);
		c.fillRect(370,600,10,25);
		c.fillRect(170,500+40,10,25);
	}
}
public boolean Exist(int x[], int y[]) {
	if(life == true) {
		boolean spriteChange = true;
		if (xLocation[0]<x[0]&& xLocation[2]>x[0] &&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<x[0]&& xLocation[2]>x[0] &&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else if (xLocation[0]<x[1]&& xLocation[2]>x[1] &&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else if (xLocation[0]<x[1]&& xLocation[2]>x[1] &&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<x[0]&& xLocation[2]>x[0]&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[1])&& xLocation[2]>(x[1])&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else {
			spriteChange =false;
		}
		if(spriteChange==true) {
			c.drawImage(spriteOfEnemyattack,xLocation[0] ,yLocation[0],60,40);
			try {
				Thread.sleep(300);
			}catch(InterruptedException e) {}
			return true;
		}
		else {
			c.drawImage(spriteOfEnemy,xLocation[0] ,yLocation[0],60,40);
		}
		}
	return false;
}
public int attackHero(){
	return damage;
}
public boolean takeDamage(int taken){
	//alter how defense works
	this.hp-=taken-defense;
	if(hp<=0) {
		life = false;
		//to end fight
		return false;
	}
	return true;
}

public boolean behave(int heroHP){
	int chance =2;
	damage=10;
	if(heroHP<100) {
		chance+=1;
	}
	if(heroHP<20) {
		chance-=1;
	}
	if(this.hp<20) {
		chance-=1;
	}
	if(this.hp>20) {
		chance+=1;
	}
	if(this.charging ==true) {
		this.chargeAttack();
	}
	else if((int)((Math.random()*10)+1+chance)>=9) {
		this.chargeEnergy();
		return false;
	}
	else{
		this.ExistAngerly();
	}
	return true;
}
public int getHp() {
	return hp;
}
public int getDamage() {
	return damage;
}

}




