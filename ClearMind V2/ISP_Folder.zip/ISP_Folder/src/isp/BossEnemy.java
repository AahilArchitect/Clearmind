package isp;
import hsa_ufa.*;
import java.awt.*; 

public class BossEnemy extends Enemy {
	/*public int hp= 30;
	private int defense=0;
	private int damage = 10;
	public boolean life=true;
	public boolean charging = false;
	public int[] xLocation = new int[3];
	public int[] yLocation = new int[3];
	public Image spriteOfEnemy = Toolkit.getDefaultToolkit().getImage("images\\SlimeDotPNG.png");
	public Image spriteOfEnemyattack = Toolkit.getDefaultToolkit().getImage("images\\Slime_attacking.png");
	public Image deathSprite = Toolkit.getDefaultToolkit().getImage("images\\Death_of_a_slime.png");
	private Console c;*/
	public BossEnemy(Console con, int x, int y, Hero hero) {
		super(con, x, y);
		spriteOfEnemy = Toolkit.getDefaultToolkit().getImage("images\\SlimeBosss.png");
		//damage+=10;
		hp+=50;
		//defense+=2;
	}

}
