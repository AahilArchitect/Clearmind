package isp;

public class tempRun {
	public void endGame(RPGGame rr) {
		rr.con.close();
		rr=new RPGGame();
		rr.setQANDA();
		rr.startGame(this);
	}
	public tempRun() {
		RPGGame r = new RPGGame();
		r.setQANDA();
		r.startGame(this);
	}
}
