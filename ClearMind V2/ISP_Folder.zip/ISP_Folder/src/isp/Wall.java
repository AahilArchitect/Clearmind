package isp;

public class Wall {
	public String type;
	//North,west,south,east-- which button can no longer work(W,S,A,D)
	int [] xRange = new int [2];
	int[] yRange= new int[2];
	boolean visi;
	boolean active;
	public Wall(int[] dimensions, String typee, boolean visible) {
		this.type = typee;
		xRange[0] = dimensions[0];
		xRange[1] = dimensions[1];
		yRange[0] = dimensions[2];
		yRange[1] = dimensions[3];
		this.visi = visible;
		this.active=true;
	}
	public void deActivate() {
		this.active = false;
	}
	public boolean hitQuestionMark(int x, int y) {
		if(this.active) {
			if (xRange[0]<x && xRange[1]>x &&yRange[0]<y&&yRange[1]>y&&active==true) {
				return true;
			}
		}
		return false;
	}
	public void visibility() {
		
	}
}


