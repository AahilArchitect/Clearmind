package isp;

public class runner {
	public void endGame(RPGGame g) {
		
	}
	public static void main(String[]args) {
		RPGGame r = new RPGGame();
		r.setQANDA();
		r.startGame();
	}
}



