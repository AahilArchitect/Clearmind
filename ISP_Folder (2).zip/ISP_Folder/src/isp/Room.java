package isp;
import hsa_ufa.*;
import java.awt.*;
public class Room{
private int id; //huh
private String type; //huh
public Enemy[] enemy;
public boolean isBossRoom;
public int howManyEnemy;
private Wall[] walls;
private int wallNumber;
public Image background;
public Image fightBG;
private Console c;
public int[] startPlacement = new int[4];
public int[] endPlacement = new int[4];
public int[] falseWall = new int[4];
//public boolean somethingOccurs;

public Room(String im, int wallNum, int []wallLocations, Console con, int[] start, String[] directions, int[] end) {
	//wallLocations can feed into the initialization of each wall object for this room
	this.c = con;
	background = Toolkit.getDefaultToolkit().getImage(im);
	fightBG= Toolkit.getDefaultToolkit().getImage("images\\fightBG.png");
	this.walls = new Wall [wallNum+1];
	this.wallNumber=wallNum;
	endPlacement = end;
	startPlacement = start;
	howManyEnemy = (int)((Math.random()+1)*2);
	enemy = new Enemy [howManyEnemy];
	int tempx, tempy,counter=0;
	int [] temporary = new int[4];
	Boolean ok = true;
	for(int i = 0; i<=wallNum;i++) {
		for(int ii = 0; ii<4; ii++) {
			temporary[ii] = wallLocations[counter+ii];
		}
		counter += 4;
		if (i== 0){
			walls[i]= new Wall(temporary, directions[i],true);
		}
		else{
			walls[i]= new Wall(temporary, directions[i],false);
		}
		c.fillRect(temporary[0], temporary[2],(temporary[1]-temporary[0]), (temporary[3]-temporary[2]));
	}
	for(int i = 0; i<howManyEnemy;i++) {
		//edit this later to ensure enemies can't spawn on walls either
		do {
			tempx = (int)(Math.random()*780);
			tempy = (int)(Math.random()*650);
			//adaptive with heros start ,, which depends on the room ahh
			if (overStart(tempx,tempy)==true) {
				ok = false;
			}
			else if(hitWall(tempx, tempy)==true) {
				ok = false;
			}
			else {
				ok = true;
			}
		} while(ok == false);
		enemy[i] = new Enemy(c, tempx,tempy,false);
		//actual drawing of enemy will be moved to enemy object later and run either through room by hero or just by hero
	}	
	
}
public boolean hitWall(int x,int y){
	for(int i = 0; i<=wallNumber;i++) {
			if(walls[i].hitQuestionMark(x, y)==true) {
				return true;
			}
			else if((walls[i].type.compareToIgnoreCase("North")==0)&&(walls[i].hitQuestionMark(x, y-60)==true)) {
				return true;
			}
	}
	
	return false;
}
public boolean hitWall(int x,int y, String typ){
	for(int i = 0; i<=wallNumber;i++) {
		if(walls[i].type.compareToIgnoreCase(typ)==0) {
			if(walls[i].hitQuestionMark(x, y)==true) {
				return true;
			}
		}
	}
	return false;
}
public Enemy getEnemy(int which){
	return enemy[which];

}
public void blockade() {
	if(walls[0].visi == true) {
		c.setColor(Color.black);
		c.fillRect(walls[0].xRange[0],walls[0].yRange[0], walls[0].xRange[1], walls[0].yRange[1]);

	}
	else {

	}
}
public void checkEnemiesDead() {
	for(int i =0;i<howManyEnemy;i++) {
		if(enemy[i].life==true) {}
		else {
			walls[0].active= false;
			walls[0].visi= false;
			//falseWall blow up animation?
		}
	}
}
public boolean overEnd(int x[],int y[]) {
	if (endPlacement[0]<x[0] && endPlacement[1]>x[0] &&endPlacement[2]<y[0]&&endPlacement[3]>y[0]) {
		return true;
	}
	else if(endPlacement[0]<x[1] && endPlacement[1]>x[1] &&endPlacement[2]<y[1]&&endPlacement[3]>y[1]) {
		return true;
	}
	else if(endPlacement[0]<x[0] && endPlacement[1]>x[0] &&endPlacement[2]<y[1]&&endPlacement[3]>y[1]) {
		return true;
	}
	else if(endPlacement[0]<x[1] && endPlacement[1]>x[1] &&endPlacement[2]<y[0]&&endPlacement[3]>y[0]) {
		return true;
	}
	else {
		return false;
	}
}
public boolean overStart(int x,int y) {
	if (startPlacement[0]<x && startPlacement[1]>x &&startPlacement[2]<y&&startPlacement[3]>y) {
		return true;
	}
	else {
		return false;
	}
}
/*public boolean isBossRoom(){
	
	return false;
}*/
}


