package isp;
import hsa_ufa.*;
import java.awt.*;
public class Enemy{
public int hp= 30;
private int defense=0;
private int damage = 10;
private String aiState;
public boolean life=true;
//what
//give boss special attacks and enemies a 25% chance to charge for double damage
//private boolean attacking= false;
private boolean isBoss=false;
//x and y location [2] will be the hit box end
public int[] xLocation = new int[3];
public int[] yLocation = new int[3];
public Image spriteOfEnemy = Toolkit.getDefaultToolkit().getImage("images\\SlimeDotPNG.png");
public Image spriteOfEnemyattack = Toolkit.getDefaultToolkit().getImage("images\\Slime_attacking.png");
public Image deathSprite = Toolkit.getDefaultToolkit().getImage("images\\Death_of_a_slime.png");
private Console c;
//make use of javas garbage collection to kill enemies? don't name them and use  hero or room reference?
public Enemy(Console con, int x, int y, boolean bossNess) {
	//make boss a child of enemy
	this.c = con;
	xLocation[0]= x;
	xLocation[1]= x+50;
	yLocation[0]= y;
	yLocation[1]= y+50;
	xLocation[2]= x+30;
	yLocation[2]= y+30;
	isBoss(bossNess);
}
public void Exist() {

	c.drawImage(spriteOfEnemy,170 ,500,200,150);
}
public void ExistAngerly() {
	c.drawImage(spriteOfEnemyattack,170 ,500,200,150);
}
public boolean Exist(int x[], int y[]) {
	if(life == true) {
		boolean spriteChange = true;
		if (xLocation[0]<x[0]&& xLocation[2]>x[0] &&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<x[0]&& xLocation[2]>x[0] &&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else if (xLocation[0]<x[1]&& xLocation[2]>x[1] &&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else if (xLocation[0]<x[1]&& xLocation[2]>x[1] &&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<y[0]&&yLocation[2]>y[0]) {}
		else if (xLocation[0]<x[0]&& xLocation[2]>x[0]&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[1])&& xLocation[2]>(x[1])&&yLocation[0]<(y[0]+50)&&yLocation[2]>(y[0]+50)) {}
		else if (xLocation[0]<(x[0]+25)&& xLocation[2]>(x[0]+25)&&yLocation[0]<y[1]&&yLocation[2]>y[1]) {}
		else {
			spriteChange =false;
		}
		if(spriteChange==true) {
			c.drawImage(spriteOfEnemyattack,xLocation[0] ,yLocation[0],60,40);
			try {
				Thread.sleep(300);
			}catch(InterruptedException e) {}
			return true;
		}
		else {
			c.drawImage(spriteOfEnemy,xLocation[0] ,yLocation[0],60,40);
		}
		}
	return false;
}
public int attackHero(){
	return damage;
}
public boolean takeDamage(int taken){
	//alter how defense works
	this.hp-=taken-defense;
	if(hp<=0) {
		life = false;
		//to end fight
		return false;
	}
	return true;
}

public boolean behave(){
	//makes choices,, returns whether or not it attacks 
	//call attackHero 
	return true;
}
public int getHp() {
	return hp;
}
public int getDamage() {
	return damage;
}
private void isBoss(boolean v) {
	if(v==true) {
		spriteOfEnemy = Toolkit.getDefaultToolkit().getImage("images\\SlimeBosss.png");
		damage+=10;
		hp+=50;
		defense+=2;
	}
}
}




